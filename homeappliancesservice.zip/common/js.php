<?php  ?>

<script data-cfasync="false" src="../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/jquery-3.6.0.min.js"></script>
		<script src="assets/js/modernizr.min.js"></script>
		<script src="assets/js/bootstrap.bundle.min.js"></script>
		<script src="assets/js/imagesloaded.pkgd.min.js"></script>
		<script src="assets/js/jquery.magnific-popup.min.js"></script>
		<script src="assets/js/isotope.pkgd.min.js"></script>
		<script src="assets/js/jquery.appear.min.js"></script>
		<script src="assets/js/jquery.easing.min.js"></script>
		<script src="assets/js/owl.carousel.min.js"></script>
		<script src="assets/js/counter-up.js"></script>
		<script src="assets/js/wow.min.js"></script>
		<script src="assets/js/main.js"></script>