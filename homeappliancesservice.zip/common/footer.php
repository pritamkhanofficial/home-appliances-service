<?php  ?>


<footer class="footer-area">
			
			<!-- <div class="footer-contact-info">
				<div class="container">
					<div class="row">
						<div class="col-md-6 col-lg-3">
							<div class="contact-info-item">
								<span class="contact-info-icon"><i class="far fa-map-marker-alt"></i></span>
								<div>
									<h5>Address</h5>
									<p>10/B Milford, New York</p>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-3">
							<div class="contact-info-item">
								<span class="contact-info-icon"><i class="far fa-phone"></i></span>
								<div>
									<h5>Call Us</h5>
									<p>+2 123 6544 778</p>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-3">
							<div class="contact-info-item">
								<span class="contact-info-icon"><i class="far fa-envelope"></i></span>
								<div>
									<h5>Email Us</h5>
									<p><a href="https://live.themewild.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="8ce5e2eae3cce9f4ede1fce0e9a2efe3e1">[email&#160;protected]</a></p>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-3">
							<div class="contact-info-item">
								<span class="contact-info-icon"><i class="far fa-clock"></i></span>
								<div>
									<h5>Opening</h5>
									<p>Sun - Fri (08AM - 10PM)</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div> -->
			<div class="copyright">
				<div class="container">
					<div class="row">
						<div class="col-lg-6 align-self-center">
							<p class="copyright-text">
								&copy; Copyright <span id="date"></span> <a href="#"> Home Appliance </a> All
								Rights Reserved.
							</p>
						</div>
						<div class="col-lg-6 align-self-center">
							<ul class="footer-menu">
								<li><a href="#">Support</a></li>
								<li><a href="#">Terms Of Services</a></li>
								<li><a href="#">Privacy Policy</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</footer>