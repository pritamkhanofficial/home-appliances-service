<?php  ?>

<div class="header-top">
				<div class="container-fluid px-lg-5">
					<div class="header-top-wrapper">
						<div class="header-top-left">
							<div class="header-top-contact">
								<ul>
									<li><a href="#"><i class="far fa-map-marker-alt"></i> Jagatpur Main Rd, Gauranganagar, NEWTOWN, Kolkata, West Bengal 700156</a></li>
									<li><a href=""><i class="far fa-envelope"></i> example@gmail.com</a></li>
									<!-- <li><a href="#"><i class="far fa-clock"></i><span>Opening:</span> Sun - Fri (08AM - 10PM)</a></li> -->
								</ul>
							</div>
						</div>
						<div class="header-top-right">
							<div class="header-top-social">
								<a href="#"><i class="fab fa-facebook-f"></i></a>
								<a href="#"><i class="fab fa-twitter"></i></a>
								<a href="#"><i class="fab fa-instagram"></i></a>
								<a href="#"><i class="fab fa-whatsapp"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>